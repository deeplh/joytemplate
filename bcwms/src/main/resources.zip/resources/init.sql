-- 权限sql
insert into `deep`.`BasUserRoleRelation` ( `basRoleId`, `createTime`, `createUserId`, `userId`, `serviceId`, `serviceType`)
values ( '1', '2018-08-19 16:01:03', null, '12', null, null);